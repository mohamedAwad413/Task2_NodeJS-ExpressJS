const express = require('express');
const mongoose = require("mongoose");
const Student = require("./models/MyDataSchema");
const path = require("path");

const app = express();
const port = 3000;

// =======================
// إعدادات عامة
// =======================
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "views")));
app.set("view engine", "ejs");

// =======================
// اتصال بقاعدة البيانات
// =======================
mongoose.connect("mongodb://localhost:27017/StudentDB")
  .then(() => {
    app.listen(port, () => console.log(`🚀 Server running: http://localhost:${port}`));
    console.log("✅ Connected to MongoDB locally");
  })
  .catch(err => console.error("❌ Connection error:", err));

// =======================
// 🧩 Routes
// =======================

// 🏠 الصفحة الرئيسية (إضافة طالب جديد)
app.get("/", (req, res) => {
  res.render("index");
});

// ✅ صفحة النجاح بعد الإضافة
app.get("/success.html", (req, res) => {
  res.render("success");
});

// ➕ إضافة طالب جديد (CREATE)
app.post("/", async (req, res) => {
  try {
    const coursesArray = req.body.courses
      .split(",")
      .map(course => course.trim())
      .filter(c => c);

    const newStudent = new Student({
      name: req.body.name,
      department: req.body.department,
      courses: coursesArray,
      degree: req.body.degree,
      age: req.body.age,
    });

    await newStudent.save();
    res.redirect("/success.html");
  } catch (error) {
    console.error("❌ Error creating student:", error);
    res.status(400).send({ message: "Error creating student", error });
  }
});

// 📋 عرض جميع الطلاب (READ)
app.get("/students", async (req, res) => {
  try {
    const students = await Student.find();
    res.render("students", { myTitle: "Students", students, searchQuery: "" });
  } catch (err) {
    res.status(400).send({ message: "Error viewing students", err });
  }
});

// ✏️ عرض صفحة تعديل طالب (GET)
app.get("/students/update/:id", async (req, res) => {
  try {
    const student = await Student.findById(req.params.id);
    if (!student) {
      return res.status(404).send("Student not found");
    }
    res.render("editStudent", { myTitle: "Edit Student", student });
  } catch (error) {
    console.error("Error fetching student:", error);
    res.status(500).send("Internal server error");
  }
});

// 💾 تعديل بيانات طالب (UPDATE)
app.post("/students/update/:id", async (req, res) => {
  try {
    const coursesArray = req.body.courses
      .split(",")
      .map(course => course.trim())
      .filter(c => c);

    await Student.findByIdAndUpdate(req.params.id, {
      name: req.body.name,
      department: req.body.department,
      courses: coursesArray,
      degree: req.body.degree,
      age: req.body.age,
    });

    res.redirect("/students");
  } catch (error) {
    console.error("❌ Update error:", error);
    res.status(400).send({ message: "Error updating student", error });
  }
});

// ❌ حذف طالب (DELETE)
app.post("/students/delete/:id", async (req, res) => {
  try {
    await Student.findByIdAndDelete(req.params.id);
    res.redirect("/students");
  } catch (error) {
    console.error("❌ Delete error:", error);
    res.status(400).send({ message: "Error deleting student", error });
  }
});

// 🔍 البحث عن الطلاب بالاسم أو القسم أو الكورس (SEARCH)
app.get("/students/search", async (req, res) => {
  try {
    const query = req.query.q?.trim() || "";

    const students = await Student.find({
      $or: [
        { name: { $regex: query, $options: "i" } },
        { department: { $regex: query, $options: "i" } },
        { courses: { $regex: query, $options: "i" } }
      ]
    });

    res.render("students", {
      myTitle: "Search Results",
      students,
      searchQuery: query
    });
  } catch (error) {
    console.error("❌ Search error:", error);
    res.status(500).send("Error searching students");
  }
});
